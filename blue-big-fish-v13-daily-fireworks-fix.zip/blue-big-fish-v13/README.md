# 藍色大肥魚 V13 Android Game

This project rebuilds the Android app and home-screen widget around the 11.0 HTML game source.

## Features
- App screen uses the embedded 11.0 character art, sound, squish animation, and five response phrases.
- The five phrases are selected with `Random.nextInt(5)` in the widget.
- App and widget share a daily click count in Android SharedPreferences.
- The count rolls over when the local calendar date changes.
- Widget uses a white square-style card with a dark navy border. Only the maid image is clickable.
- Widget taps play the embedded squeak sound, show a phrase briefly, update the shared count, and apply a brief bitmap squash effect.

## Build
Open this folder as an Android Gradle project, or use the GitHub Actions workflow supplied alongside the project archive.

Package: `com.cocoisq.bluebigfish`
Version: `13.0` (versionCode 13)
